package com.example.chapter_03

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
